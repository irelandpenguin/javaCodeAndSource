package com.yida_08.test;

public class TestDemo {

	public static void main(String[] args) {
		TestString st = new TestString();
		//st.test1();
		//st.test2();
		st.test3();
	}

}
